<div id="left">
			<form action="#" method="GET" class='search-form'>
				<div class="search-pane">
					<input type="text" name="search" placeholder="Search here...">
					<button type="submit">
						<i class="fa fa-search"></i>
					</button>
				</div>
			</form>
			<div class="subnav">
				<div class="subnav-title">
					<a href="#" class='toggle-subnav'>
						<i class="fa fa-angle-down"></i>
						<span>Inventory</span>
					</a>
				</div>
				<ul class="subnav-menu">
					
					<li>
						<a href="#">Item Issue</a>
					</li>
					<li>
						<a href="#">Diesel Demand Issue</a>
					</li>
					<li>
						<a href="#">Tyre Mapping</a>
					</li>
                    
                    <li>
						<a href="#">Truck Documents </a>
					</li>
				</ul>
			</div>
			<div class="subnav">
				<div class="subnav-title">
					<a href="#" class='toggle-subnav'>
						<i class="fa fa-angle-down"></i>
						<span>Payroll</span>
					</a>
				</div>
				<ul class="subnav-menu">
					<li>
						<a href="#">Driver Advance</a>
					</li>
					
					<li>
						<a href="#">Driver Salary</a>
					</li>
                    
                    
					
				</ul>
			</div>
			<div class="subnav">
				<div class="subnav-title">
					<a href="#" class='toggle-subnav'>
						<i class="fa fa-angle-down"></i>
						<span>Accounts</span>
					</a>
				</div>
				<ul class="subnav-menu">
					<li>
						<a href="#">Other Expenses</a>
					</li>
					
					<li>
						<a href="#">Other Income</a>
					</li>
				</ul>
			</div>
			<div class="subnav subnav-hidden">
				<div class="subnav-title">
					<a href="#" class='toggle-subnav'>
						<i class="fa fa-angle-right"></i>
						<span>Maintenance</span>
					</a>
				</div>
				<ul class="subnav-menu">
					<li>
						<a href="#">Trcuk Labour Charge</a>
					</li>
					
					<li>
						<a href="#">Truck Part Service</a>
					</li>
				</ul>
			</div>
		</div>